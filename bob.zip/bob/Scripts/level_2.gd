extends Node2D


@onready var Player = get_tree().current_scene.get_node("Player")
@onready var Deathcoin = $Deathcoin

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	RenderingServer.set_default_clear_color(Color(0.431, 0.631, 0.431, 1.0))


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	Deathcoin.velocity = Deathcoin.velocity.move_toward(Deathcoin.position.direction_to(Player.position) * 200, 200 * delta)
	Deathcoin.velocity = Deathcoin.velocity.move_toward(Vector2.ZERO, 10000 * (1/Deathcoin.position.distance_to(Player.position)) * delta)
	Deathcoin.move_and_slide()
