extends CharacterBody2D

signal is_spike_touched


var touched: bool = false


func _on_area_2d_body_entered(body: Node2D) -> void:
	if touched or not body.is_in_group("Player"): return
	touched = true
	
	print("TOUCHED")
	is_spike_touched.emit()
	
	await get_tree().create_timer(1.5).timeout
	touched = false
