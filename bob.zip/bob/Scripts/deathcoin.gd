extends Area2D

#signal reset_position
#
#
#var touched: bool = false
#
#func _on_body_entered(body: Node2D) -> void:
	#if touched or not body.is_in_group("Player"): return
	#touched = true
	#
	#print("TOUCHED")
	#reset_position.emit()
	#
	#await get_tree().create_timer(2).timeout
	#touched = false
