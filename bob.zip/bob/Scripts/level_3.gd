extends Node2D


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	RenderingServer.set_default_clear_color(Color(0.431, 0.631, 0.431, 1.0))
	for Scissors in $Spikes.get_children():
		Scissors.get_node("AnimatedSprite2D").animation = &"colored"
	for Coin in $Coins.get_children():
		Coin.get_node("AnimatedSprite2D").animation = &"colored"


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass
